These are makehuman related plugins which can be added to blender.
